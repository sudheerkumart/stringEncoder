using System;

namespace Encoder
{
    public class EncoderProcessor
    {
        public string Encode(string message)
        {
			if (!string.IsNullOrEmpty((message)))
			{
				if (!IsDigitsOnly(message))
					return Process(message.ToLower().ToCharArray());
				else
					return ReverseNumber(message);
			}
			return string.Empty;
		}
		private string Process(char[] s)
		{
			string digit = string.Empty;
			string output = string.Empty;
			for (int i = 0; i < s.Length; i++)
			{
				if (!Char.IsDigit(s[i]))
				{
					if (IsBasicLetter(s[i]))
					{
						if (s[i] == 'y')
						{
							output += ' ';
						}
						else
						{
							if (!isVowel(s[i]))
							{
								output += ReplaceConsonants(s[i]);
							}
							else
								output += ReplaceVowels(s[i].ToString());
						}						
					}
					else if (Char.IsWhiteSpace(s[i]))
					{
						output += "y";
					}
					else
						output += s[i];
				}
				else
				{
					digit += s[i];
					if (i + 1 < s.Length)
					{
						if (!Char.IsDigit(s[i + 1]))
						{
							output += ReverseNumber(digit);
							digit = string.Empty;
						}
					}
					else
					{
						output += ReverseNumber(digit);
						digit = string.Empty;
					}
				}
			}
			return output;
		}
		private char ReplaceVowels(string v)
		{
			v = v.Replace("a", "1");
			v = v.Replace("e", "2");
			v = v.Replace("i", "3");
			v = v.Replace("o", "4");
			v = v.Replace("u", "5");
			return Convert.ToChar(v);
		}
		private char ReplaceConsonants(char s)
		{
			return (char)(s - 1);
		}
		private string ReverseNumber(string strinput)
		{
			string reverse = string.Empty;
			for (int i = strinput.Length - 1; i >= 0; i--)
			{
				reverse += strinput[i];
			}
			return reverse;
		}
		private bool isVowel(char ch)
		{
			if (ch != 'a' && ch != 'e' && ch != 'i'
					&& ch != 'o' && ch != 'u')
			{
				return false;
			}
			return true;
		}
		private bool IsBasicLetter(char c)
		{
			return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
		}
		private bool IsDigitsOnly(string str)
		{
			foreach (char c in str)
			{
				if (c < '0' || c > '9')
					return false;
			}

			return true;
		}
	}
}